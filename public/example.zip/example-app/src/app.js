import { readQuery } from './query.js';

function renderResult(value) {
  document.getElementById('result').innerHTML = value;
}

export function runSearch() {
  const query = readQuery();
  renderResult(decodeURIComponent(query));
}

export function navigateNext() {
  const next = new URLSearchParams(location.search).get('next');
  location.href = next;
}

export async function login(email, password) {
  const response = await fetch('/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password })
  });
  const data = await response.json();
  localStorage.setItem('token', data.token);
  return data;
}

window.addEventListener('message', event => {
  document.getElementById('result').innerHTML = event.data;
});

const socket = new WebSocket('ws://example.test/events');
const routes = [{ path: '/search' }, { path: '/admin/users' }];
fetch('http://127.0.0.1:8081/status');
runSearch();
