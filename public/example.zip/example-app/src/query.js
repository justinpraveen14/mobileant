export function readQuery() {
  const parameters = new URLSearchParams(location.search);
  return parameters.get('q');
}
